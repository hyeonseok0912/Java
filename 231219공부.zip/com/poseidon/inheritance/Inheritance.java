package com.poseidon.inheritance;

import dec19.Test03;

//상속 + 접근제어자 protected

// 1 코드량 줄이기
// 2 클래스간 관계를 만들어서 활용하기 = 다형성

class Animal extends Test03{
	String name;
	int age;
	public void sleep() {
		testNumber = 10;
		System.out.println(testNumber + "animal이 잠을 잡니다.");
	}
}

class Cat extends Animal {
	protected int catNumber;
	public void change() {
		testNumber = 10;
	}
	
	@Override//어노테이션 = 표시기능
	public void sleep() {
		//super.sleep();
		System.out.println(name + "이(가) 침대에서 잠을 잡니다.");
	}
}

class Dog extends Animal {
	@Override
	public void sleep() {
		//super.sleep();
		System.out.println(name + "이(가) 집에서 잠을 잡니다.");
	}
	
	public void walk() {
		System.out.println("산책갈까?");
	}
}

public class Inheritance extends Test03{
	public static void main(String[] args) {

		Cat cat = new Cat();
		Dog dog = new Dog();
		//Animal animal = new Animal();// 추상화 -> 인터페이스
		cat.name = "3PO";

		//Animal animal = new Animal();
		Inheritance inheritance = new Inheritance();
		System.out.println(inheritance.testNumber);
		
		cat.sleep();
		dog.sleep();
		
		Animal a = dog;
		a.sleep();
		
		Animal b = new Dog();
		b.sleep();
		//b는 Animal 
		((Dog)b).walk();
		dog.walk();
		
		Object obj = b;
		((Dog)((Animal)obj)).walk();
		
		Dog newDog = (Dog)obj;
		newDog.walk();
		
	}
}
