package polymorphism;

import java.util.ArrayList;
import java.util.List;

//다형성 polymorphism
/*
 * 다형성은 동적 바인딩이 지원되는 프로그램 언어에서 사용할 수 있습니다.
 * 
 * 런타임때 최종 타입이 결정됩니다.
 * 
 * 하나의 객체가 여러가지 형태를 가질 수 있는 것
 * 
 * 자바의 다형성은 한 타입의 참조변수를 통해 여러 타입의 객체를 참조할 수 있도록 하는 것.
 * 상위 클래스 타입의 참조변수를 통해 하위 클래스의 객체를 참조할 수 있도록
 * 허용하여 상위 클래스가 동일한 메시지로 하위 클래스들이 서로 다른 동작을
 * 할 수 있게 하는 것
 * 
 * 다형성을 활용하면 부모 클래스가 자식 클래스의 동작 방식을 알 수 없어도
 * 오버라이딩을 통해 자식 클래스에 접근할 수 있다.
 * 
 * 장점
 * 	유지보수 : 여러 객체를 하나의 타입으로 관리할 수 있다.
 * 	재사용성 : 객체의 재사용이 쉽다.
 * 	느슨한 결합 : 클래스간의 의존성을 줄여 응집도는 높아지고 결합도는 낮아진다.
 * 
 * 다형성의 조건
 * 상위 클래스와 하위 클래스는 상속 관계여야 한다.
 * 다형성이 보장되기 위해서 오버라이딩이 반드시 필요하다.
 * 자식 클래스의 객체가 부모 클래스의 타입으로 형변환 해야한다.
 */

class Hero {
	String name;

	void attack() {
		System.out.println("공격");
	}
}

class Ironman extends Hero {
	public void makeSuit() {
		System.out.println("javis, 슈트 만들어.");
	}

	@Override
	void attack() {
		System.out.println("레이저 공격");
	}
}

class Hulk extends Hero {
	@Override
	void attack() {
		System.out.println("펀치!");
	}
}

class Superman extends Hero {

}

class Xman extends Hero {

}

public class Polymorphism {
	public static void main(String[] args) {

		Ironman iron = new Ironman();
		Hero h = new Ironman();// 반드시 부모 클래스가 앞에 나와야 합니다.

		iron.makeSuit();
		// h.makeSuit(); // 저런 메소드가 없기 때문에
		Ironman mark2 = (Ironman)h;
		mark2.makeSuit();
		
		((Ironman)h).makeSuit();
		
		Hulk hulk = new Hulk();
		hulk.attack();
		
		//((Ironman)((Hero)hulk)).makeSuit(); -> 안됨
		
		Hero avengers[] = new Hero[5];
		avengers[0] = new Ironman();
		avengers[1] = new Hulk();
		avengers[2] = new Superman();
		avengers[3] = new Xman();
		avengers[4] = new Ironman();
		
		for (Hero hero : avengers) {
			hero.attack();
		}
		
		List<Integer> list = new ArrayList<Integer>();
		
		Hero hero = new Hero(); // 이런 일을 방지하고자 추상화가 나옵니다
	}
}
