package abstractEx;
//추상화

/*
 * 자바에서는 추상화라는 개념이 있습니다.
 * 
 * 추상 : 현실화 되어질 필요가 없는, 인스턴스화 되어질 필요가 없는 클래스
 * 
 * 		---> 인스턴스화 할 필요강 ㅓㅄ는 성질의 클래스
 * 
 * 자바에서는 객체지향을 통해 프로그램이 실행되는데
 * 이 추상이라는 개념을 클래스에 적용시키면
 * 자신의 인스턴스를 발생할 수 없는 형태로 지정됩니다.
 * 
 * 이렇게 인스턴스화 할 필요가 없지만 상속 개념에서 중요한 위치를 가지는
 * 클래스를 보통 추상 클래스로 정의합니다.
 * 
 * 선언규칙
 * 1. 클래스에 정의된 메소드 중 추상 메소드가 하나라도 있다면
 * 	  해당 클래스는 무조건 추상 클래스가 됩니다.
 * 	  추상 클래스는 class 앞에 abstract 라고 적어줍니다.
 * 
 * 2. 추상 메소드는 메소드 바디가 없는 형태
 * 	  추상 메소드는 abstract 라는 키워드를 리턴 타입 앞에 선언합니다.
 * 	  파라미터 괄호() 뒤에 세미콜론; 붙여서 명령을 끝냅니다.
 * 
 * 3. 추상 클래스는 자신의 인스턴스를 발생시키지 못합니다.
 * 	  하지만 생성자, 멧드,  필드는 모두 선언 및 정의할 수 있습니다.
 * 	  또한 상속도 가능합니다.
 * 	  또한 Super type으로 존재 가능하므로 다형성도 적용됩니다.
 * 
 * 4. 만약 추상 클래스가 되고 싶다면 class 앞에 abstract 붙이면 됩니다.
 * 
 */

abstract class Hero {// 추상 클래스
	String name;
	int age;

	public abstract void attack();// 추상 메소드

	public abstract void sleep();

	void eat() {

	}// 바디가 있다 = 정상 메소드
}

class Ironman extends Hero {
	@Override
	public void attack() {
		System.out.println("레이저 공격");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub

	}

	@Override
	void eat() {
		// TODO Auto-generated method stub

	}
}

class Hulk extends Hero {
	@Override
	public void attack() {
		System.out.println("몸통 박치기");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub

	}

	@Override
	void eat() {
		// TODO Auto-generated method stub

	}
}

class Spiderman extends Hero {

	@Override
	public void attack() {// 미구현된 메소드를 자식 클래스에서 구현

	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub

	}

	@Override
	void eat() {
		// TODO Auto-generated method stub

	}
}

class Hawkeye extends Hero {

	@Override
	public void attack() {// 바디 {}가 있다면 구현한 것으로 인정

	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub

	}

	@Override
	void eat() {
		// TODO Auto-generated method stub

	}

}

public class AbstractEx {
	public static void main(String[] args) {
		// Hero hero = new Hero();
	}
}
