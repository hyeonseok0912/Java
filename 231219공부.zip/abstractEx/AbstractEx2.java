package abstractEx;

/*추상클래스 : 인터페이스의 역할도 하면서 클래스 같은 돌연변이 클래스
 * 
 * 추상 클래스를 만들기 위해서는 class 앞에 abstract를 붙인다.
 * 내부 메소드에서도 abstract를 붙이고 바디를 제거합니다.
 * 인터페이스와 동일하게 메소드 몸통{}이 없다.
 * 	-> 상속받는 자식 클래스에서 미구현된 메소드를 구현해주어야 합니다.
 * 
 * 추상 클래스 : 객체를 만들 수 없는 클래스
 * 
 * 추상 메소드 : 바디가 없는 메소드(내용이 없다)
 * 			  미완성된, 구현이 없는, 바디가 없는 메소드
 * 			  = 하위 클래스에서 구현합니다. (오버라이드)
 * 			  하위 클래스에서 구현을 강제로 하게 합니다.
 * 			  = 프로그램 구조가 확실해 집니다.
 */
public class AbstractEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
