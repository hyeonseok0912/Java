package dec19;

public class Test03 {
	protected int testNumber;
	
	protected void testMethod() {
		
	}
}
