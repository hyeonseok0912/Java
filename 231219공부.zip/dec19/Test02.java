package dec19;
//2023-12-19
//어제 했던 것
/*
 * static
 * 		변수, 메소드 앞에 붙여요.
 * 		클래스에 붙어서 동작합니다.
 * 		인스턴스 생성 없이 사용합니다.
 * 		하나만 생성해서 사용할 때.
 * 		상수 사용할 때. final(수정 불가)
 * 
 * 접근제어자
 * 					클래수내부	|	  패키지		|	 상속		|	기타
 * 		public : 	   o           o              o          o
 * 		protected :    o		   o 			  o			 o
 * 		default : 	   o		   o			  x          x
 * 		private : 	   o		   x 			  x 		 x
 * 
 * 상속
 * 		유산
 * 		클래스간의 관계를 설정해서 부모 자식관계를 만듬
 * 		부모 - 자식
 * 		상위 - 하위
 * 		super - sub
 * 		부모의 모든 내용을 자식이 사용할 수 있습니다.
 * 		class 자식 extends 부모 {}
 * 		단, 부모의 private 변수/메소드는 상속할 수 없습니다.
 * 		부모와 자식 클래스가 서로 다른 패키지에 있다면 부모의 default 붙은
 * 		필드/메소드는 자식이 물려받을 수 없습니다.
 * 
 * 		부모의 생성자 호출 super()
 * 		내 생성자 호출 this()
 * 
 * 		내 인스턴스의 변수 this
 * 
 * 외부 라이브러리 사용하기
 * 
 * 오늘 할 거
 * 		오버라이드
 * 		오버로드
 * 		다형성
 * 		추상화
 */

class A{
	static int number;//기울어지는 것
	int num;//안 기울여짐
}

class B{
	static B b = null;
	private int num;//외부에서 볼 수 없음
	
	private B() {
		System.out.println("생성자입니다.");
	}
	
	public static B getInstance() {
		if(b == null) {
			return b = new B();
		}else {
			return b;
		}
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
}

public class Test02 {
	public static void main(String[] args) {
		
		A a = new A();
		A.number = 10;//static은 클래스명.static변수명
		
		A.number = 100;
		System.out.println(A.number);
		
		B b = B.getInstance();
		B b2 = B.getInstance();
		B b3 = B.getInstance();
		B b4 = B.getInstance();
		
		b.setNum(1);
		b2.setNum(2);
		b3.setNum(3);
		b4.setNum(4);
		
		System.out.println(b.getNum());
		System.out.println(b2.getNum());
		System.out.println(b3.getNum());
		System.out.println(b4.getNum());
	}
}
