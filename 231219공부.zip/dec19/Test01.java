package dec19;

public class Test01 {

	public static void main(String[] args) {
//		System.out.println("!@#$%^&*(\\'\"<>?:;");
//		System.out.println("\n");
//		System.out.println("\t");
//		System.out.println("check");
//		System.out.println("\"문자열\"");//"문자열"
//		System.out.println("'문자열'");
//		System.out.println("/");
//		System.out.println("\\");
//		System.out.println("\\\\\\\\");
		
		System.out.println("\\   /\\\n ) ( ')\n(  /  )\n \\(__)|");
		System.out.println("================");
	}

}
