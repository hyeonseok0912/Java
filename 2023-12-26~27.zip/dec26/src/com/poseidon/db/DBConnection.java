package com.poseidon.db;
// 접속 정보만 가지고 있는 클래스

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	public Connection getConnection() {  // getConnection메소드를 만들고
		// 리턴타입이 Connection다. 즉, Connection이 나옴
			Connection con = null;
			// 욕심은 싱글턴 패턴화 시키는거?
			
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				String url = "jdbc:mariadb://guro.wisejia.com:3307/employees";
				String user = "c23c_13";
				String pw = "538389";
				con = DriverManager.getConnection(url, user, pw);
				
			} catch (ClassNotFoundException e) {
				System.out.println("클래스가 없습니다.");
				
			} catch (SQLException e) {
				//e.printStackTrace();
				System.out.println("접속 정보를 확인하세요.");
			}
			
			return con;
		
	}
	
}