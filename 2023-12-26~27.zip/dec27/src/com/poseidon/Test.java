package com.poseidon;

import java.util.List;

import com.poseidon.dao.EmployeesDAO;
import com.poseidon.dto.EmployeesDTO;

public class Test {

	public static void main(String[] args) {

		EmployeesDAO dao = new EmployeesDAO();
		List<EmployeesDTO> list = dao.selectEmployees();
		
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getEmp_no());
		}

	}
}
