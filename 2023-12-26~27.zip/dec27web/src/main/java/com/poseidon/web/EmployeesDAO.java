package com.poseidon.web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//데이터 접속 객체(Data Access Object)
public class EmployeesDAO {
	DBConnection dbConn = new DBConnection();
	
	public List<EmployeesDTO> selectEmployees() {
		List<EmployeesDTO> result = null;
		//접속 정보
		Connection con = dbConn.getConnection();
		//각종 객체
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM employees LIMIT 0, 10";
		//sql
		
		//로직
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery(); //select문은 옆 메소드로 실행합니다.
			
			result = new ArrayList<EmployeesDTO>();
			while (rs.next()) {
				EmployeesDTO dto = new EmployeesDTO();
				dto.setEmp_no(rs.getInt("emp_no"));
				dto.setBirth_date(rs.getString(2));
				dto.setFirst_name(rs.getString(3));
				dto.setLast_name(rs.getString(4));
				dto.setGender(rs.getString(5).charAt(0));
				dto.setHire_date(rs.getString(6));
				
				result.add(dto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	
	public List<EmployeesDTO> selectDepartments(){
		List<EmployeesDTO> result = null;
		//데이터베이스 접속정보
		Connection conn = dbConn.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		//sql
		String sql = "SELECT * FROM departments";

		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			//데이터 만드는 작업
			result = new ArrayList<EmployeesDTO>();
			
			while (rs.next()) {
				EmployeesDTO dto = new EmployeesDTO();
				dto.setDept_no(rs.getString(1));
				dto.setDept_name(rs.getString(2));
				result.add(dto);
			}
			
		} catch (SQLException e) {
			//e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return result;
	}
}
