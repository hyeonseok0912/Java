package com.higher.web;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.higher.web.service.MemberService;

@SpringBootTest
class WebApplicationTests {
   @Autowired
   MemberService memberService;
   
   @DisplayName("로그인 카운트 값 확인합니다.")
   
   @Test
   void contextLoads() {
      //Map<String, Object> map = new HashMap<String, Object>();
      //map.put("id", "shin");
      //map.put("pw", "01234567");
      
      //Map<String, Object> result = memberService.login(map);
      
      //assertEquals(1, Integer.parseInt(String.valueOf(result.get("count"))));
      //result에 담겨진 count값이 1인지 확인하는 메소드
      int num = 100;
      assertEquals(100, num);
   }
}