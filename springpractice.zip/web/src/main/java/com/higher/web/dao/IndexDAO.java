package com.higher.web.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.higher.web.dto.BoardDTO;
import com.higher.web.dto.FreeBoardDTO;

@Repository
@Mapper
public interface IndexDAO {

	List<Map<String, Object>> boardList();

	Map<String, Object> detail(int no);

	List<Map<String, Object>> board(int cate);

	int write(Map<String, Object> map);

	List<Map<String, String>> menu();

	int postDel(int no);

	Map<String, Object> detail2(int no);

	void postUpdate(Map<String, Object> map);

	Object getcateName(int cate);
}