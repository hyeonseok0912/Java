package com.higher.web.controller;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.higher.web.util.Util;

@Controller
public class APIController {

	@GetMapping("/airKorea")
	public String airKorea(Model model) throws IOException, ParseException {
		// 스트링 빌더 - 값이 계속 수정될때
		// buffer랑도 차이가 있다.
		StringBuilder urlBuilder = new StringBuilder(
				"http://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMinuDustFrcstDspth");
		urlBuilder.append(
				"?serviceKey=HJgibudK9Afx20kYaSuXyTpqsz%2FB6jklYelcEggRxY8sZoeb6XVYF5EDUqGnZ0Xu0Ai1Z7o0rogCFPHh0geWtA%3D%3D");
		urlBuilder.append("&returnType=json");
		urlBuilder.append("&numOfRow=100");
		urlBuilder.append("&pageNo=1");
		urlBuilder.append("&searchDate=2024-03-11");
		urlBuilder.append("&informCode=PM10");

		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		System.out.println("Response code: " + conn.getResponseCode());

		//주석 처리할 부분
//		BufferedReader rd;
//		if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
//			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//		} else {
//			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
//		}
//
//		// 메모리 때문에 빌더를 씀
//		StringBuilder sb = new StringBuilder();
//		String line; // 한줄한줄 읽어올것인데
//		// 몇줄인지 모르니 while문으로
//		// line = rd.readLine() != null 한줄 씩 읽어오는데 값이 없다면 null처리
//		while ((line = rd.readLine()) != null) {
//			sb.append(line);
//		}
//
//		rd.close();
//		conn.disconnect();
//		System.out.println(sb.toString());

		// data.go.kr에서 에어코리아 접속해서 데이터 불러오기
		
		// json -> 자바 데이터 타입형태로 변경 -> 출력
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(new InputStreamReader(url.openStream()));
		//System.out.println(jsonObject.toJSONString());
		
		Map<String, Object> map = (Map<String, Object>) jsonObject.get("response");
		//System.out.println("response : " + map);
		map = (Map<String, Object>) map.get("body");
		//System.out.println("body : " + map);
		JSONArray jsonArray = (JSONArray) map.get("items");
		//System.out.println("items : " + jsonArray);
		
		model.addAttribute("data", jsonArray);
		
		
		return "airkorea"; // 반드시 URL과 같을 필요가 없습니다.
	}
	
	@GetMapping("/airKoreaXML")
	public String airKoreaXML(Model model) throws IOException, ParserConfigurationException, SAXException {
		// 스트링 빌더 - 값이 계속 수정될때
		// buffer랑도 차이가 있다.
		StringBuilder urlBuilder = new StringBuilder(
				"http://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getMinuDustFrcstDspth");
		urlBuilder.append(
				"?serviceKey=HJgibudK9Afx20kYaSuXyTpqsz%2FB6jklYelcEggRxY8sZoeb6XVYF5EDUqGnZ0Xu0Ai1Z7o0rogCFPHh0geWtA%3D%3D");
		urlBuilder.append("&returnType=xml");
		urlBuilder.append("&numOfRow=100");
		urlBuilder.append("&pageNo=1");
		urlBuilder.append("&searchDate=2024-03-11");
		urlBuilder.append("&informCode=PM10");

		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Content-type", "application/json");
		System.out.println("응답 결과: " + conn.getResponseCode());
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = factory.newDocumentBuilder();
		//Document document = documentBuilder.parse(conn.getInputStream());
		Document document = documentBuilder.parse(conn.getInputStream());
		document.getDocumentElement().normalize();
		
		System.out.println("response : " + document.getDocumentElement().getNodeName()); //node nodeName == DOM
		
		NodeList list = (NodeList) document.getDocumentElement().getChildNodes().item(3);//body
		System.out.println(list.getLength());
		System.out.println(list.item(1).getNodeName());//items
		
		NodeList list2 = list.item(1).getChildNodes();//items
		//System.out.println("items :: " + list2.getLength());
		//System.out.println("items :: " + list2.item(0).getNodeName());
		
		//List 아래 맵을 20개 담아서 보내는 리스트
		List<Map<String, Object>> listMap = new ArrayList<>(); //20개를 담습니다.
		for (int i = 1; i < list2.getLength();  i++) {
			NodeList list3 = list2.item(i).getChildNodes();//item == 13개
			
			//Map 각각의 데이터를 담아주는 맵
			Map<String, Object> ele = new HashMap<>();
			for (int j = 1; j < list3.getLength(); j++) {
			    Node node = list3.item(j);
			    if(node.getNodeType() == Node.ELEMENT_NODE) {
			        String nodeName = node.getNodeName();
			        String textContent = node.getTextContent();
			        System.out.println(j + " : " + nodeName + " : " + textContent);
			        if(nodeName != null && textContent != null) {
			            //담기 노드 이름을 키로, 글 내용을 값으로
			            ele.put(nodeName, textContent);
			        }
			    }
			}
			listMap.add(ele);
		}
		
		model.addAttribute("data", listMap);
		
		return "airkoreaXML"; // 반드시 URL과 같을 필요가 없습니다.
	}
	
	@GetMapping("/html")
	   public String html() throws IOException {
	      
	      org.jsoup.nodes.Document doc = Jsoup.connect("https://www.clien.net/service/").get();
	      
	      Elements element = doc.select("a.menu-list.somoim > .menu_over");
	      
	      System.out.println(element.size()); //몇 개?
	      
	      for (Element ele : element) {
	         System.out.println(ele.text());
	      }
	      
	      //System.out.println(doc);
	      return "html";
	   }
}