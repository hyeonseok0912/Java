package com.higher.web.dto;

import lombok.Data;

@Data
public class BoardDTO {
	
	private int board_no, board_count, comment;
	private String board_title, board_write, board_content, board_date, board_ip;
	
}