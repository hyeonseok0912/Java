package com.higher.web.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.higher.web.dao.IndexDAO;
import com.higher.web.util.Util;
@Service
public class IndexService {
	@Autowired
	private IndexDAO indexDAO;

	@Autowired
	private Util util;

	public List<Map<String, Object>> boardList() {
		return indexDAO.boardList();
	}

	public Map<String, Object> detail(int no) {
		return indexDAO.detail(no);
	}

	public List<Map<String, Object>> freeboard(int cate) {
		return indexDAO.board(cate);
	}

	public int write(Map<String, Object> map) {
		map.put("mid", util.getSession().getAttribute("mid"));
		map.put("ip", util.getIP());
		return indexDAO.write(map);
	}

	public List<Map<String, String>> menu() {
		return indexDAO.menu();
	}

	public int postDel(int no) {
		return indexDAO.postDel(no);
	}

	public void postUpdate(Map<String, Object> map) {
		map.put("mid", util.getSession().getAttribute("mid"));// 본인 맞는지
		indexDAO.postUpdate(map);
	}

	public Object getcateName(int cate) {
		return indexDAO.getcateName(cate);
	}

}