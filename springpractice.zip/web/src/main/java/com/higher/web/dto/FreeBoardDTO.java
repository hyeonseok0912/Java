package com.higher.web.dto;

import lombok.Data;

@Data
public class FreeBoardDTO extends BoardDTO {
	
	private int mtno, mno, mtdel, mtread, mtcate;
	private String mttitle, mtcontent, mtip, mtdate, mname;
	
}