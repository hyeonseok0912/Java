package com.higher.web.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.higher.web.dao.MemberDAO;
import com.higher.web.util.Util;
@Service
public class MemberService {

	@Autowired
	private MemberDAO memberDAO;
	
	@Autowired
	Util util;
	
	public Map<String, Object> login(Map<String, Object> map) {
		return memberDAO.login(map);
	}

}
