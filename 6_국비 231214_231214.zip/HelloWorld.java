package dec14;

public class HelloWorld {

	public static void main(String[] args) {
		// 여기는 객체 생성구문,
		// 호출
		HelloWorld helloWorld = new HelloWorld();
		for (int i = 0; i < 10; i++) {
			helloWorld.hello();
		}

		String str = new String();
		// 바퀴를 두번 만들지 말라.

	}// main 메소드

	// 다른 메소드
	public void hello() {
		System.out.println("Hello~");
	}

}

//여기나, 다른 파일로 제작합니다.