package oop;

class Human {// 클래스는 절대 겹치지 않게, 메소드 속X, 클래스 속 X
	// 속성 = 변수
	String name;
	int age = 1;
	String addr;//주소
	
	// 생성자
	public Human(String name, int age) {// 생성자는 리턴타입이 없습니다.
		this.name = name;
		this.age = age;
	}
	
	public Human(String name, int age, String addr) {
		this.name = name;
		this.age = age;
		this.addr = addr;
	}
	
	// 기능 = 메소드
	int add(int num, int num2) {
		return num + num2;
	}

}

public class OOP2 {
	
	int add(int num1, int num2) {
		return num1 + num2;
	}

	public static void main(String[] args) {
		// 인간
		// Human h1 = new Human();
		Human h1 = new Human("홍길동", 1);// 생성자
		
		System.out.println(h1);//oop.Human@73a28541
		System.out.println(h1.name);
		System.out.println(h1.age);
		
		Human h2 = new Human("김길동", 5);
		System.out.println(h2.name);
		System.out.println(h2.age);
		
		Human h3 = new Human("금수저", 10, "강남");
		System.out.println(h3.name);
		System.out.println(h3.age);
		System.out.println(h3.addr);
		
	}

}
