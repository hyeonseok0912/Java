package dec14;

class Cat {
	// 속성 : 변수
	String name; // 초기화 안해요.
	int aggressive = 50;
	int hand = 0;

	// 생성자 : 인스턴스를 생성할 때 사용하는 메소드
	public Cat(String name) {
		this.name = name;
	}

	// 기능 : 메소드
	public void stroke(int count) {

		int hand = 0;
		int num = 1;
		for (int i = 0; i < count; i++) {
			hand++;
			if (aggressive > 60) {
				System.out.println("공격력이 " + aggressive + "입니다.");
				System.out.println(name + "(이)가 당신의 손을 할큅니다.");
			} else {
				System.out.println(num++ - 1 + "회 만졌습니다");
				System.out.println("공격력이 1 올라갑니다");
				System.out.println("공격력 : " + aggressive++);
				if (aggressive == 60) {
					System.out.println("이 이상 만지면 화냅니다.");
				}
				if (hand > 5 && hand < 10) {
					System.out.println("고양이를 만집니다.");
					System.out.println("고양이가 무야호~");
				}
			}
		}
	}

	public int sleep() {
		System.out.println(name + "(이)가 잠을 잡니다.");
		return this.name.length();
	}

	public int add(int num1, int num2) {
		int num3 = num1 + num2;
		return num3;
	}
}

public class CM01 {

	public static void main(String[] args) {
		Cat cat1 = new Cat("아롱이");
		Cat cat2 = new Cat("다롱이");
		Cat cat3 = new Cat("메롱이");
		Cat cat4 = new Cat("헤롱이");

		Cat cats[] = new Cat[4];
		cats[0] = cat1;
		cats[1] = cat2;
		cats[2] = cat3;
		cats[3] = cat4;

		for (Cat c : cats) {
			c.sleep();
		}

		cat1.stroke(10);

		for (int i = 0; i < 20; i++) {
			cat1.stroke(1);
		}
		System.out.println(cat1.aggressive);
		System.out.println(cat2.aggressive);

		int length = cat1.sleep();
		System.out.println(length);

		int result = cat4.add(10, 20);
		// 호출할 때는 파라미터 수, 순서, 타입에 맞게

		System.out.println(result);
	}

}
