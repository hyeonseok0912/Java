package test;

// 2022년 2회차 17번
class Conv {
	public Conv(int a) {
		this.a = a;
	}

	int func() {//기능
		int b = 1;	// b = 1
		for (int i = 1; i < a; i++) {// a= 5, b= 51
			b = a * i + b;
		}
		return a + b; //56
	}

	int a;//속성
}

public class Test01 {
	public static void main(String[] args) {
		Conv obj = new Conv(3);// a = 3;
		obj.a = 5;// a = 5;
		int b = obj.func();
		System.out.println(obj.a + b);// // 5 + 56
	}
}
