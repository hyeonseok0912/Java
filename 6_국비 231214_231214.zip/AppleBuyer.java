package apple;
//사과를 사는 사람

import java.util.Scanner;

public class AppleBuyer {
	//속성
	//필요한 정보
	//가지고 있는 사과의 수
	int appleCount;
	//보유 금액
	int buyerMoney = 10000;

	
	//생성자
	
	
	//기능
	//사과를 사는 기능
	//내 정보를 말하는 기능
	//메소드 명은 tellBuyer
	//"구매한 사과는 " + appleCount + "개 입니다."
	//"남은 돈은 " + buyerMoney + "원 입니다."
	public void tellBuyer() {
		System.out.println("구매한 사과는 " + appleCount + "개 입니다.");
		System.out.println("남은 돈은 " + buyerMoney + "입니다.");
	}
}
