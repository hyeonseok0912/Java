package test;

import dec14.HelloWorld;
import oop.OOP2;

public class Test03 {

	public static void main(String[] args) {
		// Human
		OOP2 oop2 = new OOP2();
		// public 붙은 클래스는 패키지를 뛰어넘어 사용할 수 있습니다.
		HelloWorld hw = new HelloWorld();
		
		dec14.OOP2 oop = new dec14.OOP2();
		oop.toString();
	}

}
