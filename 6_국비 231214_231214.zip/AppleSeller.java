package apple;

import java.util.Scanner;

//사과를 파는 사람
public class AppleSeller {
	//속성
	//필요한 정보
	//사과 가격 apple price -> 상수
	final int APPLE_PRICE = 1000;
	//사과 수
	int appleCount = 50;
	//보유 금액
	int sellerMoney;
	
	
	//생성자
	
	
	//기능
	//사과를 파는 기능
	//내 정보를 말하는 기능
	//메소드 명은 tellSeller
	//"남은 사과는 " + appleCount + "개 입니다."
	//"수익은 " + sellerMoney + "원 입니다."
	public void tellSeller() {
//		System.out.println("사과를 몇 개 판매하시겠습니까?");
//		Scanner sc = new Scanner(System.in);
//		appleCount = sc.nextInt();
//		sellerMoney = (50 - appleCount) * APPLE_PRICE;
		System.out.println("남은 사과는" + appleCount + "개 입니다");
		System.out.println("수익은 " + sellerMoney + "입니다.");
	}
	
}
