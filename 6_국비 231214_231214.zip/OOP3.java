package oop;

public class OOP3 {

	public static void main(String[] args) {
		Human h = new Human(null, 0, null);
		
		OOP2 oop2 = new OOP2();
		
		int result = h.add(10, 30);
		System.out.println(result);
	}

}
