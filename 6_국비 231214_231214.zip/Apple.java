package apple;
//두 인스턴스가 발생하는 장소
public class Apple {
	public static void main(String[] args) {
		AppleSeller seller = new AppleSeller();
		seller.tellSeller();
	}
}
