package dec14;

public class OOP2 {
	int num = 10;

	public String toString() {
		String text = "저는 dec14에 있는 OOP입니다";
		return text;
	}

}
