package oop;

public class OOP1 {

	public static void main(String[] args) {

	}

}
