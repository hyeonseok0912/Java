package com.poseidon.wrapper;

/*
 *  랩퍼클래스	(498)
 *  주방에서 사용하는 랩 = 포장
 *  컬렉션은 R타입만 담을 수 있어요.
 *  P타입을 R타입으로 감싸서 저장하면 됩니다.
 *  
 *  기본 자료형의 값을 컬렉션에 담기 위해서는 랩퍼 클래스를 사용합니다.
 *  기본 자료형에 대해서는 그에 대응하는 랩퍼 클래스가 있습니다.
 *  기본 자료형의 값을 멤버 변수의 값으로 저장하고
 *  이 값 주위로 값을 가공하는 메소드들이 감싸고 있다고 해서
 *  랩퍼(wrapper)클래스라고 합니다.
 *  
 *   기본 자료형					랩퍼 클래스
 *     byte						 Byte
 *     short					 Short 
 *     int						 Integer---
 *     long						 Long
 *     float					 Float
 *     double					 Double
 *     char						 Character---
 *     boolean					 Boolean
 *  
 *  
 */


public class WrapperEx {
	public static void main(String[] args) {
		int num = 100;
		Integer number = 100;
		Integer number2 = new Integer(100);
		
		num = number2;
		byte bNum = number2.byteValue();
		short sNum = number2.shortValue();
		double dNum = number2.doubleValue();
		
		Short number3 = 100;
		bNum = number3.byteValue();
		
		System.out.println(Integer.MAX_VALUE);
		
		//정수 기본형의 최솟값
		System.out.println(Integer.MIN_VALUE);
		//byte 형의 최솟값은?
		System.out.println(Byte.MIN_VALUE);
		
		/*박싱 언방식
		 * 기본 타입의 값을 포장 객체로 만드는 과정(Boxing)
		 * 반대로 포장 객체에서 기본타입의 값을 꺼내는 Unboxing
		 */
		
		Integer integer = 30;
		Integer integer2 = new Integer("30");
		Integer integer3 = Integer.valueOf("300");
		// Integer integer = new Integer(30); 이렇게 변경합니다.
		// 오토박싱
		// 형변환이 아닙니다. 기본 자료형이 참조형으로 바뀝니다.
		
		if(integer == integer2) {
			System.out.println("같은 값입니다.");
		}else {
			System.out.println("다른 값입니다.");
		}
	}
}
