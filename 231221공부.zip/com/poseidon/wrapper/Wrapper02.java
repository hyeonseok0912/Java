package com.poseidon.wrapper;

public class Wrapper02 {

	public static void main(String[] args) {
		/*
		 * 포장값 비교하기 포장값 비교하기 위해서 ==, =! 같은 연산자를 사용하지 않는 것 이 연산자는 내부 값을 비교하는 것이 아니라 포장
		 * 객체의 참조를 비교
		 */
		Integer obj1 = 127;
		Integer obj2 = 127;

		System.out.println(obj1 == obj2);

		Integer obj3 = 300;
		Integer obj4 = 300;

		System.out.println(obj3 == obj4);

		// 값 비교는?
		// compareTo()

		obj2 = 300;

		int result = obj1.compareTo(obj2);
		System.out.println(result);

		if (result == 0) {
			System.out.println("값이 같습니다.");
		} else if (result < 0) {
			System.out.println("다릅니다 / obj2가 클 때");
		} else {
			System.out.println("다릅니다 / obj1이 클 때");
		}

		// R -> P
		// 오토 언박싱
		
		int iNum = obj1;
		
		Object obj = 40;
		
		iNum = (int)obj;//큰 타입에서는 작은 타입으로 안들어가짐
		iNum = ((Integer)obj).intValue();
		
		
	}

}
