package com.poseidon.coll;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class List01 {

	public static void main(String[] args) {
		
		// 1~45 숫자중 랜덤으로 6개를 뽑아 리스트에 넣어주세요.
		ArrayList<Integer> list = new ArrayList<>();
		
		for(int i = 0; i < 6; i++) {
			list.add((int)(Math.random()* 45 + 1));
		}
		System.out.println(list);
		
		Collections.sort(list);
		System.out.println(list);
		
		Collections.sort(list, Collections.reverseOrder());
		System.out.println(list);
	}

}
