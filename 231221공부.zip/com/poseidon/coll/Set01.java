package com.poseidon.coll;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

// List : 순서가 있습니다. 중복을 허용합니다.
// Set : 순서가 없습니다. 중복을 허용하지 않습니다.
// Map : 
public class Set01 {
	public static void main(String[] args) {
		
		Set<String> set = new HashSet<String>();
		set.add("홍길동");
		set.add("김길동");
		set.add("이길동");
		set.add("박길동");
		set.add("최길동");
		set.add("홍길동");
		
		System.out.println(set);// [박길동, 김길동, 홍길동, 최길동, 이길동]
								// 중복허용 X
		System.out.println(set.size());// 중복 제외 값 리턴
		
		
		System.out.println("==============================");
		//로또 시스템 만들어보기
		Set<Integer> setLotto = new HashSet<Integer>();
		
		while(setLotto.size() < 6) {
		for(int i = 0; i < 6; i++) {
			setLotto.add((int)(Math.random() * 45 + 1));
			}
		
		}
		System.out.println(setLotto);
		
		// set을 list로 만들어서 출력하기
		List<Integer> list2 = new ArrayList<>(setLotto);
		System.out.println(list2);
		
		for (int i = 0; i < list2.size(); i++) {
			System.out.println(list2.get(i));
		}
		
		Collections.sort(list2);
		
		System.out.println("========");
		// foreach 출력하기
		for (Integer integer : list2) {
			System.out.println(integer);
		}
		
		System.out.println("============Iterator==========");
		//Iterator 반복자 = 리스트를 순회할 수 있게 해주는 객체
		Iterator<Integer> iter = setLotto.iterator();
		
		while(iter.hasNext()) {
			Integer integer = (Integer) iter.next();
			System.out.println(integer);
		}
		/*
		 * 반복자
		 * 컬렉션 인터페이스의 iterator()메소드는 Iterator를 리턴합니다.
		 * Iterator는 Enumeration 인터페이스와 비슷하나 Enumeration보다
		 * 나중에 만들어졌습니다.
		 * 
		 * 
		 */
		
		List<String> names = new ArrayList<String>();
		names.add("홍길동");
		names.add("김길동");
		names.add("최길동");
		names.add("홍길동");
		names.add("홍길동");
		names.add("홍길동");
		names.add("이길동");
		names.add("홍길동");
		names.add("홍길동");
		
		System.out.println(names.size());
		// set은 중복을 허용하지 않기에, list를 set으로 변환하여 출력
		Set<String> names2 = new HashSet<String>(names);
		System.out.println(names2.size());
		System.out.println(names2);
	}
}
