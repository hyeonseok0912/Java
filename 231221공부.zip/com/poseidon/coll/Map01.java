package com.poseidon.coll;

import java.util.HashMap;
import java.util.Map;

/*
 * List : 순서 O, 중복 O
 * Set : 순서 X, 중복 X
 * Map : 키와 값을 쌍으로 저장합니다. (570)
 * 		 키는 중복 X, 값은 중복 O
 */
public class Map01 {
	public static void main(String[] args) {
		
		Map<String, String> map = new HashMap<>();
		map.put("밀양", "사과");
		map.put("수원", "왕갈비");
		map.put("춘천", "닭갈비");
		map.put("수원", "반도체");// 키 중복, 키 중복은 중복 저장하지 않음
		
		System.out.println(map.size());
		System.out.println(map);
		
		//하나만 출력 = 키를 알아야 값을 뽑아요.
		System.out.println(map.get("밀양"));
		
		//키가 있는지 물어보기
		boolean key = map.containsKey("수원");
		key = map.containsKey("화성");
		System.out.println(key);
		
		//값이 있는지 물어보기
		boolean key2 = map.containsValue("굴비");
		System.out.println(key2);
		
		
	}
}