package com.poseidon.coll;

import java.util.ArrayList;

public class List02 {
	public static void main(String[] args) {
		//문자열 저장하는 list1 만들어주세요.
		ArrayList<String> list1 = new ArrayList<>();
		
		list1.add("홍길동");
		list1.add("김길동");
		list1.add("이길동");
		list1.add("박길동");
		list1.add("최길동");
		list1.add("남길동");
		System.out.println(list1.size());
		
		list1.remove("홍길동");
		System.out.println(list1.size());
		System.out.println(list1);
		
		list1.remove("남길동");
		System.out.println(list1.size());
		System.out.println(list1);
		
	}
	
}
