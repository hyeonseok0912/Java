package com.poseidon.coll;

import java.util.ArrayList;
import java.util.List;

public class List03 {

	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList(); // <>이게 제네릭, 타입 결정
		list.add(1);
		
		int number = list.get(0);
		System.out.println(number);
	}

}
