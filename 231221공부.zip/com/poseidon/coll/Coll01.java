package com.poseidon.coll;

import java.util.ArrayList;
import java.util.List;

// 컬렉션
// List, Set, Map
/*
 * 클래스 선언부에 <E>, <T>, <K, V>가 붙은 것을 볼 수 있습니다.
 * 이것은 제네릭이라고 합니다. (자바 1.5)
 * E 요소 Element
 * T 타입 Type
 * K, V 키,값 Key, Value
 * 
 */
public class Coll01 {
	public static void main(String[] args) {

//		ArrayList<Integer> list = new ArrayList<Integer>();
//		System.out.println(list.isEmpty());
//		list.add(10);
//		list.add(20);
//		list.add(0, 100);// 0번지에 100의 값을 넣어주고, 그 뒤의 값들을
//						 //	한칸씩 뒤로 민다
//		
//		list.set(2, 200);
//		list.remove(2);
//		
//		System.out.println(list);// [10, 200]
//		System.out.println(list.get(0));
//		System.out.println(list.get(1));				
//		System.out.println(list.size());// 리스트의 길이
//		System.out.println(list.isEmpty());
//		
//		for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
//			
//		}
//		
//		for (Integer integer : list) {
//			System.out.println(integer);
//		}
//		
//		list.clear();// 리스트 비우기
//		System.out.println(list.isEmpty());// 비어있어?
//		
//		ArrayList<Integer> list2 = new ArrayList<Integer>();
//		ArrayList<Integer> list3 = new ArrayList<>();
		List<Integer> list4 = new ArrayList<>();
		
		//1~10까지 입력, list4 index 짝수만
//		int num = 1;
//		for(int i = 0; i < 10; i++) {
//			list4.add(num);
//			num++;
//		}
//		System.out.println(list4);
//		
//		for(int i = 0; i < list4.size(); i++) {
//			if(i % 2 == 0) {
//				list4.remove(i);
//			}
//		}
//		System.out.println(list4);
		
		//[2, 4, 6, 8, 10]
		for(int i = 1; i <= 10; i++) {
	         if(i % 2 == 0) {            
	            list4.add(i);
	         }
	      }
	      
	      for(int i = 0; i < list4.size(); i++) {
	         System.out.println(list4.get(i));
	      }
	}
}
