package com.poseidon.coll;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//set에 하나의 값만 저장하는데, 그게 처음 값인지, 나중에 들어온 값인지?
public class Set02 {
	public static void main(String[] args) {

		Set<String> set1 = new HashSet<>();
		set1.add("홍길동");
		set1.add("홍길동");
		set1.add("홍길동");
		set1.add("홍길동");
		set1.add("홍길동");

		String name = new String("홍길동");
		System.out.println(System.identityHashCode(name));
		set1.add(name);

		name = new String("박길동");
		System.out.println(System.identityHashCode(name));

		System.out.println(set1.size());

		// 클래스를 만들어서 static 변수로 값을 변경시켜 저장해보겠습니다.

		Set<Human> humans = new HashSet<Human>();
		Human n =new Human();
		
		humans.add(n);// 1
		n.ssn = 10;
		humans.add(n);// 10
		n.ssn = 20;
		humans.add(n);// 20
		n.ssn = 30;
		humans.add(n);// 30
		n.ssn = 40;
		humans.add(n);// 40?
		
		List<Human> humanList = new ArrayList<>(humans);
		System.out.println(humanList.get(0).ssn);// 40
		//같은 주소값에 다른 숫자들을 넣었기 때문에 결국 40만 저장되어 출력됨
		//중복저장 x, 정렬 x
	}

}

class Human {
	int ssn;
	static int number;

	public Human() {
		this.ssn = this.ssn + number;
	}
}
