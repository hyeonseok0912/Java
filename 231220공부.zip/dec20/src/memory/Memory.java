package memory;

//메모리구조
/*
 * 중요 : 호출 스택은 예외처리 할 때 필요합니다.
 * 
 * 메소드 영역 : 클래스 데이터 (클래스 변수)
 * 			  프로그램 실행 중 어떤 클래스가 사용되면 JVM은
 * 			  해당 클래스 파일을 읽어서 클래스 데이터를 이곳에 저장합니다.
 * 			  동시에 클래스 변수도 이곳에 생성합니다.
 * 
 * 호출 스택 : 메인 메소드(지역변수)
 * 			메소드가 작업에 필요한 메모리 공간을 제공해줍니다.
 * 			메소드가 호출되면 호출스택에 메소드 활용을 위한 메모리가 할당됩니다.
 * 			메모리에서 메소드가 작업을 수행하는 동안 지역변수와
 * 			연산의 중간 결과가 저장됩니다.
 * 
 * 			메소드가 작업을 마치면 할당되었던 메모리 공간은 반환 ->
 * 			비워집니다.
 * 
 * 			호출스택은 제일 상위에 있는 메소드가 지금 실행중인 메소드
 * 
 * 			나머지는?
 * 			모두 대기를 합니다
 * 			언제나 호출스택 최상위에 있는 메소드가 지금 실행중인 메소드 입니다.
 * 			아래에 있는 메소드는?
 * 			바로 위에 있는 메소드를 호출한 메소드입니다.
 * 
 * 힙 : 인스턴스가 생성되는 공간
 *		인스턴스 변수
 *
 * 리턴타입이 있는 메소드는 종료되기 직전 결과값을 반환합니다.
 * 누구에게? 자신을 호출한 메소드에게 결과값을 반환합니다.
 * 누구? 대기 타고 있는 호출 메소드가 받아서 프로그램을 진행합니다.
 */
public class Memory {
	public static void main(String[] args) {
		System.out.println("main method start");// 1
		System.out.println("메인 메소드 작업중");// 2
		first();
		System.out.println("main method end");// 9
	}

	static void first() {
		System.out.println("first method start");// 3
		System.out.println("first 메소드 작업중");// 4
		second();
		System.out.println("first method end");// 8
	}

	static void second() {
		System.out.println("second method start");// 5
		System.out.println("second 메소드 작업중");// 6
		System.out.println("second method end");// 7
	}

}
