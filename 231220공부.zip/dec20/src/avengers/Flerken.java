package avengers;

public class Flerken extends Hero implements Attack{

	@Override
	public void attack() {
		System.out.println("먹기");
	}

	@Override
	public void defense() {
		System.out.println("Meow");
	}

}
