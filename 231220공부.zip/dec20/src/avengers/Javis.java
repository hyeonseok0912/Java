package avengers;

public interface Javis {
	public abstract void makeSuit(int count);
	
}
