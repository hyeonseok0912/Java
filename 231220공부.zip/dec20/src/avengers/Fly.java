package avengers;

public interface Fly {
	public abstract void fly();
}
