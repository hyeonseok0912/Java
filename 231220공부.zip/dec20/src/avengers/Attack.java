package avengers;

public interface Attack {
	public abstract void attack();
	void defense();
}
