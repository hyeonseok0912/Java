package avengers;

public class Avengers {

	public static void main(String[] args) {
		
		//인스턴스 생성해주시면 됩니다.
		Ironman ironman = new Ironman();
		Spiderman spiderman = new Spiderman();
		Kang kang = new Kang();
		Flerken flerken = new Flerken();
		MarikoYoshida yoshida = new MarikoYoshida();
		
		flerken.attack();
		yoshida.attack();
	}

}
