package avengers;

public abstract class Hero {
	String name;
	int age;
}
