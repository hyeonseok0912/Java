package test;

class ovr2 extends Test02 {
	int sun(int x, int y) {
		return x - y + super.sun(x, y);
	}
}

public class Test02 {
	public static void main(String[] args) {
		Test02 a1 = new Test02();
		Test02 a2 = new ovr2();
		System.out.println(a1.sun(3, 2) + a2.sun(3, 2));
	}

	int sun(int x, int y) {
		return x + y;
	}
}
