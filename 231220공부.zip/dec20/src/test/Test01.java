package test;

class Car1 implements Runnable {
	int a;

	public void run() {
		System.out.println("message");
	}
}

public class Test01 {
	public static void main(String[] args) {
		Thread t1 = new Thread(new Car1());
		t1.start();
	}
}
