package enumEx;

import java.time.DayOfWeek;

public class EnumEx {
	Week today = Week.FRIDAY;
	DayOfWeek dow = DayOfWeek.FRIDAY;
	public static void main(String[] args) {
		
	}

}
