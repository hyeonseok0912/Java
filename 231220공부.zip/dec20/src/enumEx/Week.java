package enumEx;
//열거형 타입
/*
 * 열거한 값만 사용할 수 있습니다.
 * static final값 입니다. = 대문자로 적었습니다.
 *  	= 스네이크 표기법
 * enum은 클래스 이름과 중복될 수 없습니다.
 * 같은 값을 가질 수 없습니다.
 * 
 */
public enum Week {
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
}
