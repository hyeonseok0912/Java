package com.poseidon.inter;

//인터페이스
/*
 * 다른 언어에서 찾기 힘든 자바의 고급 기능입니다.
 * (왜 써? 어떻게 써? 특징?)
 * 
 * 인터페이스란?
 * 클래스 : 일반 메소드를 가질 수 있습니다.
 * 추상 클래스 : 추상 메소드를 가질 수 있어요.
 * 인터페이스 : 오로지 추상 메소드만 가질 수 있습니다.
 * 
 * 인터페이스 내에 존재하는 메소드는 무조건 public abstract로 선언합니다.
 * 인터페이스 내에 존재하는 변수는 무조건 public static final로 선언합니다.
 * 
 * 인터페이스 내에 가질 수 있는 것들 : 
 * 
 * 인터페이스는 다중 상속과 비슷한 기능을 제공합니다.
 * 
 * interface 인터페이스명{
 * 		void 추상메소드();//바디가 없습니다. {}바디(구현부)가 없습니다.
 * }
 * 
 * class 클래스명 implements 인터페이스명 {
 * 		인터페이스에 있는 미구현 메소드 오버라이드
 * }
 * 
 * 그럼? 상속과 인터페이스의 차이점은?
 * 상속 : class A extends B
 * 		 B라는 클래스를 상속받아 A의 기능을 더한다.
 * 순수상속 -> 부모로부터 모든 권한과 재산 능력을 가져오기
 * 	
 * 인터페이스 : class A implements B
 * 			 B라는 인터페이스를 구현하겠다.
 * 권한상속 -> 인터페이스만 가져오기 : 비어있는 것을 가져와서 내가 그 속을 만들어주기
 * 
 * 상속관계 중 is a, has a 관계가 있습니다.
 * 
 * 말 그대로 is a -> ~는 ~다.
 * 		  has a -> ~는 ~를 가지고 있다.
 * 
 * class Human{
 * 		String name;
 * 		int age;
 * }
 * 
 * class Student extends Human{
 * 		int number;
 * 		int major;
 * }
 * 
 * 학생 클래스가 사람 클래스를 상속받고 있습니다.
 * 학생은 사람이다.
 * 
 * class Gun{
 * 		String name;
 * 		int shot;
 * }
 * 
 * class police{
 * 		Gun gun; //멤버 객체로 총을 가져갑니다.
 * }
 * 
 * 경찰은 총을 가지고 있다.
 */
//인터페이스 만들기
interface Do {
	// 메소드 : 추상 메소드
	public abstract void attack();

	public void play();
}

abstract class Hero {// 추상 클래스
	String name;

	// public abstract void attack();// 미완성된 메소드 = 추상 메소드
}

class Superman extends Hero implements Do {

	@Override // 부모의 메소드 자식이 재정의 해서 자신이 원하는 내용으로
	public void attack() {
		// TODO Auto-generated method stub

	}

	@Override
	public void play() {
		// TODO Auto-generated method stub

	}

}

public class Inter01 {

}
