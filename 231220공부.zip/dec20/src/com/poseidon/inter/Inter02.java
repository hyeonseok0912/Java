package com.poseidon.inter;
//interface

interface SayHi {
	public static final int NUMBER = 0;

	public abstract void sayHello();

	public abstract void sayBye();
}

public class Inter02 implements SayHi {

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub

	}

	@Override
	public void sayBye() {
		// TODO Auto-generated method stub

	}

}
