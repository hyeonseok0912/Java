package kr.co.programmers;

//2023-12-20 프로그래밍 언어활용
//인터페이스
/*
 * 자바 기초, 제어문, || 객체지향프로그래밍 -> 클래스, 메소드, 상속, 추상화
 * 자료구조 : R/P타입, 배열, 스트링, SB
 * 알고리즘 : 
 * 
 * 상속 -> 추상화 -> 인터페이스
 * 		 class   interface
 * 		 단일상속	  다중상속
 */
public class Study01 {

}
