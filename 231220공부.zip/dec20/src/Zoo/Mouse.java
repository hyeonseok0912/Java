package Zoo;

public class Mouse extends Animal implements Predator {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
