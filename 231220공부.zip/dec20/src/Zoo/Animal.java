package Zoo;

public class Animal {
	String name;
	int age;
	public void setName(String name) {//이름 저장하기
		this.name = name;
	}
}
