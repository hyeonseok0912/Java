package Zoo;

public class Cat extends Animal implements Predator, Play {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

}
