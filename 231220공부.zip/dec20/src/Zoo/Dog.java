package Zoo;

public class Dog extends Animal implements Predator{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
