package Zoo;

public interface Predator {
	public abstract String getName();//이름 불러오기 = 추상 메소드
	//몸통이 없어요 = 바디가 없다 = {}가 없다
}
