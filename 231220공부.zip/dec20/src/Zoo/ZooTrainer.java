package Zoo;

public class ZooTrainer {

	public void feed(Predator predator) {
		System.out.println(predator.getName() + "에게 밥을 줍니다.");
	}
	
}
