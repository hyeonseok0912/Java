package coll;

import java.util.ArrayList;
import java.util.List;

public class List01 {

	public static void main(String[] args) {
		//부모					//자식
		List<String> list = new ArrayList<String>();
		
		list.add("홍길동");
		list.add("김길동");
		list.add("이길동");
		list.add("박길동");
		list.add("홍길동");
		
		System.out.println(list.size());
		//System.out.println(list.get(0));
		//System.out.println(list.get(list.size()-1));
		
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
			
		}
		
		for (String string : list) {
			System.out.println(string);
		}
		
		list.add(1, "황길동");
		System.out.println(list);
		
		//새로운 컬렉션
		List<String> list2 = new ArrayList<String>();
		list2.add("데이비드");
		list2.add("워쇼스키");
		list2.add("바이드");
		
		//두개의 list를 하나로 합치기
		list.addAll(list2);
		System.out.println(list2);
		
		boolean in = list.contains("당근쿤");
		System.out.println(in);
	}

}
