package coll;
//컬렉션
/*
 * Collection
 * 	ㄴ	List(i) : 순서가 있어요. 중복된 값 저장 허용
 * 	ㄴ	Set(i) : 순서가 없어요. 중복 허용 안돼요
 * 
 * Map(i) : K, V 형식으로 저장합니다. = 딕셔너리
 */
public class coll01 {

}
