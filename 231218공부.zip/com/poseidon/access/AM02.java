package com.poseidon.access;

public class AM02 {

	public static void main(String[] args) {
		
		Human human = new Human();
		human.sleep();
		human.age = 120;
		human.name = "홍길동";

//클래스간의 관계가 있을때
		
	}

}
