package com.poseidon.access;
//접근제어자 Access Modifiers
/*
 * 자바에서는 접근제어자를 통해 각 api의 접근 권한을 제한할 수 있습니다.
 * 어렵지 않습니다. 
 * 
 * 아래는 접근제어자의 범위를 크기 순서대로 나열해 둔 것입니다.
 * 
 * public > protected > default(비어있는것) > private
 *   
 * 이 중 public은 이미 보았습니다.(모두 접근 가능이라는 의미)
 * 
 * public 	 : 가장 넓은 범위로써 패키지 제한 없이 모두 접근 가능한 상태
 * 
 * protected : 같은 패키지에서 접근 가능, 
 * 			   다른 패키지에서는 상속 받은 자식 클래스/인터페이스일 경우 가능
 * 
 * default   : 아무것도 안 붙은 형태
 * 			   아무런 접근 제한을 두지 않을 때
 * 			   같은 패키지 내에서 접근 가능
 * 			   다른 패키지에서 접근 불가 
 * 
 * private   : 같은 패키지 X, 다른 패키지 X , 오직 내 클래스에서만 가능 
 * 
 * 접근제한자는 클래스명과 생성자, 메소드, 필드에 모두 사용 가능합니다.
 * 단, 클래스에서는 public과 default만 가능합니다.
 * 
 * =========================================================================
 *            클래스 내부   |  동일 패키지 | 하위 클래스 | 그 외
 * public          O            O         O       O
 * protected       O            O         O       X 
 * default         O            O         X       X
 * private         O            X         X       X
 * 
 * 
 * 
 * 293page 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */

class Apple{//default class
	private String name;//default field
	int age;
	
	private Apple() {}
	
	static Apple getInstance() {
		return new Apple();//?
	}
	
	void print() {
		System.out.println("저는 " + name + "입니다.");
	}
	
	void setName(String name) {//setter 저장하기
		this.name = name;
	}
	String getName() {//getter 가져오기
		return name;
	}
	
	void setAge(int age) {
		if(0 > age) {
			this.age = 1;
		} else {
			this.age = age;			
		}
	}
	int getAge() {
		return age;
	}
}

public class AccessModifiers {
	public static void main(String[] args) {

		Apple a = Apple.getInstance();
		//a.name = "3PO";
		//a.age = -60;
		a.setName("3PO");
		String name = a.getName();
		System.out.println(name);
		
		
		
		
		
		
	}
}