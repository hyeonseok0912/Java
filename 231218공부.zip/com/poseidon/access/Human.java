package com.poseidon.access;
//접근제어자 연습
public class Human {
	String name;
	int age;
	
	public Human() {
		
	}
	
	void sleep() {
		System.out.println("Zzzz");
	}
}


