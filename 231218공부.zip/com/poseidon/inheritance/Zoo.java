package com.poseidon.inheritance;

class Mouse extends Animal {
	public Mouse(String name, int age) {
		super(name, age);
		System.out.println("쥐 생성자입니다.");
	}
	// 오버라이드 오버라이딩
	// 오버로드 오버로딩
	// 인터페이스는?
	// 상속
	// 정적메소드
}

class ZooKeeper extends Animal {
	public ZooKeeper(String name, int age) {
		super(name, age);
	}

	public void feed(Animal animal) {
		animal.hp++;
	}
	// 오브젝트 = 최상위 클래스
}

public class Zoo {
	public static void main(String[] args) {
		ZooKeeper keeper = new ZooKeeper("사육사", 30);
		Cat cat = new Cat("3PO", 5);
		Dog dog = new Dog("R2D2", 5);
		Mouse mouse = new Mouse("미키마우스", 120);
		// Animal cat = new Cat(); - 부모타입 형태로 자식 생성자 사용하기
		// Dog dog = new Animal(); - 자식타입이 앞에 오면 에러

		keeper.feed(cat);
		keeper.feed(dog);
		keeper.feed(mouse);
	}
}
