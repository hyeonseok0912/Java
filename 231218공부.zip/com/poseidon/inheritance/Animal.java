package com.poseidon.inheritance;

public class Animal {
	String name;
	int age;
	String breed;
	int hp;

	public Animal(String name, int age) {
		System.out.println("동물이 태어납니다.");
		this.name = name;
		this.age = age;
	}
}
