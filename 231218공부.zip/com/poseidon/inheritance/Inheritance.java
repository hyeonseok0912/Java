package com.poseidon.inheritance;
//상속

//현실에서는 부모가 자식에게 물려주는 행위
//자식은 부모의 모든 것을 자신의 것처럼 사용합니다.
//자바에서는 부모와 자식 클래스를 만들고 서로 연결합니다.
//부모의 코드를 모두 내려받아서 자식이 자신의 것처럼 씁니다.
//왜?

class A {
	int field1;

	void method1() {

	}
}

class B extends A {// 자식 B가 부모 A를 상속한다
	int field2;

	void methond2() {

	}
}

class C extends B {

}

public class Inheritance {
	public static void main(String[] args) {

		A a = new A();
		B b = new B();

		b.field1 = 100;
		b.method1();// 부모의 코드가 자식에게 내려갑니다.
		C c = new C();
		c.method1();

		Cat cat = new Cat(null, 0);
		Dog dog = new Dog(null, 0);

	}
}
