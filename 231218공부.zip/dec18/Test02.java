package dec18;

import com.poseidon.access.Human;

public class Test02 {

	public static void main(String[] args) {
		Human human = new Human();
		//human.s
	}

}
