package dec18;
//2023-12-18 프로그래밍 언어활용
// 인스턴스 멤버   정적멤버
/*
 * static 키워드
 * static은 정적 이라는 의미가 있습니다.
 * 자바에서는 정적 개념과 동적 개념이 있습니다.
 * 쉽게 표현하면 정적은 클래스가 로드되는 시점을 말합니다.
 *              동적은 로드된 클래스가 실행된 이후를 말합니다.
 * 
 * 이 중 객체는 동적 데이터라고 해서 프로그램이 실행된 이후에 발생하는
 * 대표적인 형태입니다.
 * 
 * 인스턴스 멤버
 *          인스턴스 생성시 가지게 되는 자신의 변수
 *          인스턴스명.변수명으로 호출   
 *         인스턴스를 생성한 후에 사용해야 합니다.
 *          new
 * 
 * 정적 멤버
 *          모든 객체가 공통적으로 사용하는 변수
 *          클래스명.변수명으로 호출
 *          인스턴스 없이 클래스명으로 바로 불러서 사용할 수있습니다.
 *          하나의 클래스에 하나의 변수만 사용가능합니다.
 *          인스턴스 보다는 클래스에 의지해서 사용합니다.
 *          static을 붙여서 사용합니다.
 * 
 * 사용시 주의사항
 *         인스턴스가 생성되지 않은 상태에서 호출되는 변수/메소드 이므로
 *         인스턴스 안에서만 사용되는 인스턴스 변수를 쓸 수 없습니다.
 *         정적 변수와 지역변수만 사용할 수 있습니다.
 *         
 *         정적 메소드에서 인스턴스 메소드를 호출하면 오류가 납니다.
 * 
 *         인스턴스 메소드로 객체가 생성되어야만 사용가능하기 때문입니다.
 * 
 *         정적 메소드에서 정적 메소드 호출은 가능합니다.
 *         인스턴스 메소드에서 정적 메소드 호출 가능합니다.
 * 
 *         정적 메소드는 this키워드를 쓸수 없습니다. (this는 인스턴스 생성 후 씀)
 *         (this는 인스턴스 생성 후 씀) -> this가 참조할 인스턴스가 없습니다.
 * 
 *         final 붙인 상수가 모두가 변경없이 사용하는 상수...
 *         인스턴스를 만들지 않고 쓸 수 있으면 좋습니다.
 * 
 *         그래서 final static을 붙입니다.
 */
class Cat{
   static String name;
   int age;
   static double pi = 3.14;
   
   public static void print() {
      
   }
}

public class Static01 {
   public static void main(String[] args) {
      Cat cat = new Cat();
      Cat cat2 = new Cat();
      
      cat.age=10;
      cat2.age=120;
      Cat.name="3PO";
      Cat.name="R2B2";
      
      System.out.println(cat.age);
      System.out.println(cat2.age);
      System.out.println(Cat.name);
      System.out.println(Cat.name);
   }
}
