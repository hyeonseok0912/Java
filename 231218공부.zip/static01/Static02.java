package static01;
// 사용해보기

class Car{
   String model;
   String color;
   int speed;
   int id;
   static int numbers; // static
   
   
   public Car(String model,String color, int speed) {
      this.model = model;
      this.color = color;
      this.speed = speed;
      this.id = ++numbers;
   }

   public static void aaa() {
      
   }//인스턴스 없이 호출 가능
   public void bbb() {
      aaa();
   }
   public void ccc() {}
   
}


public class Static02 {
   public static void main(String[] args) {
      Car car = new Car("i5", "흰색", 150);
      Car car2 = new Car("i5", "흰색", 150);
      Car car3 = new Car("i5", "흰색", 150);
      Car car4 = new Car("i5", "흰색", 150);
      Car car5 = new Car("i5", "흰색", 150);

      System.out.println(car.id);
      System.out.println(car2.id);
      System.out.println(car3.id);
      System.out.println(car4.id);
      System.out.println(car5.id);
      
      System.out.println(Car.numbers);
      
      //static          non-static
      /*
       * static은 non-static을 부를 수 없습니다.
       * non-static은 static을 부를 수 있습니다.
       * non-static은 this를 쓸 수 있습니다.
       * static은 this를 쓸 수 없습니다.
       * 
       * static은 클래스를 만든 직후 사용가능합니다. (인스턴스 X)
       * non-static은 인스턴스 생성 후에 사용합니다.
       * 
       * 
       * 딱 하나만 만들어서 써야할때
       *    데이터베이스 접속 정보
       */
   }
}
