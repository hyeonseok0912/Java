package zoo;
//여러분들은 동물원 사육사

class Mouse{
	String name;
	int age;
	String breed;
	int hp;
}

class Horse{
	String name;
	int age;
	String breed;
	int hp;
}

class Bunny{
	String name;
	int age;
	String breed;
	int hp;
}

class ZooKeeper{
	public void feed(Mouse mouse) {//오버라이딩
		mouse.hp++;
	}
	public void feed(Horse horse) {//오버라이딩
		horse.hp++;
	}
	public void feed(Bunny bunny) {
		bunny.hp++;
	}
}

public class Zoo {
	public static void main(String[] args) {
		ZooKeeper keeper = new ZooKeeper();
		Mouse mouse = new Mouse();
		Horse horse = new Horse();
		Bunny bunny = new Bunny();
		
		keeper.feed(horse);
		keeper.feed(mouse);
		keeper.feed(bunny);
	}
}
