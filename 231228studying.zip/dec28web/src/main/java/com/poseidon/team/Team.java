package com.poseidon.team;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Team {
    public List<List<String>> getTeam() {
        List<List<String>> teams = new ArrayList<>();
        List<String> members = new ArrayList<>();
        Collections.addAll(members,
                "강기병", "김지훈", "나우석", "노재희", "박대종",
                "박선우", "박시호", "신동일", "신유진", "배현배",
                "백건하", "손현석", "신진수", "오상민", "오초록",
                "이남규", "이문희", "이민우", "이수현", "이지은",
                "이진선", "정은숙", "정진수", "정효진", "채영선",
                "한솔범"
        );

        Collections.shuffle(members);

        for (int i = 0; i < 4; i++) {
            List<String> team = new ArrayList<>();
            for (int j = 0; j < 5; j++) {
                team.add(members.remove(0));
            }
            teams.add(team);
            
            Collections.sort(members);
            Collections.sort(team);
        }

        List<String> remainingTeam = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            remainingTeam.add(members.remove(0));
        }
        teams.add(remainingTeam);
        
        Collections.sort(members);
        Collections.sort(remainingTeam);

        return teams;
    }

    public static void main(String[] args) {
        Team team = new Team();
        List<List<String>> result = team.getTeam();

        for (int i = 0; i < result.size(); i++) {
            System.out.println("Team " + (i + 1) + ": " + result.get(i));
        }
    }
}