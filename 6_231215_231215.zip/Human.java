package com.poseidon.constructor;

public class Human {
	String name;
	int age;
	String addr;
	int money;

	public Human(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	
	public void setMoney(int m) {
		this.money = m;
	}
	
	public int getMoney() {
		return money;
	}
	
	//setter
	public void setAddr(String addr) {
		this.addr = addr;
	}
	//getter
	public String getAddr() {
		return this.addr;
	}
}
