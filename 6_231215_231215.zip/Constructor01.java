package com.poseidon.constructor;

/*
 * 2023-12-15 프로그래밍 언어활용
 * 
 * 생성자
 * 생성자란 클래스가 인스턴스화 되어질 때 인스턴스를 생성시켜주는 코드를 말합니다.
 * 
 * 생성자는 이외에도 아래와 같은 기능이 있습니다.
 * 1. 클래스의 인스턴스 생성
 * 2. 멤버 필드 초기화
 * 3. 필요에 따라서 초기화 메소드를 실행해줍니다.
 * 
 * 즉, 생성자 없이는 인스턴스를 발생시킬 수 없습니다.
 * 
 * 생성자의 형식
 * 메소드와 유사하게 생겼습니다. 하지만 메소드와 기능적인 부분에서 차이가 있습니다.
 * 1. 생성자 이름은 반드시 클래스 이름과 같아야 합니다.
 * 2. 메소드가 아니기 때문에 리턴타입을 선언할 수 없습니다.
 * 
 * 기본 생성자(Default Constructor)
 * 자바에서는 모든 클래스마다 컴파이시에 기본 생성자를 자동으로 넣어줍니다.
 * 단, 클래스에 생성자가 하나라도 있다면 기본 생성자를 제공하지 않습니다.
 * 
 * 기본 생성자는 파라미터가 없는 생성자를 말합니다.
 * 이 기본 생성자를 통해서 생성된 객체를 기본 객체라고 합니다.
 * 또한 모든 필드 값은 깁ㄴ 값으로 초기화 됩니다.
 */
class Apple {
	String name;
	int age;
	int money;

	Apple(String name) {// 생성자
		this.name = name;
	}
	
	Apple(String name, int age) {// 생성자
		//this.name = name;
		this(name);//생성자 호출
		this.age = age;
	}

	Apple(String string, int i, int j) {// 생성자
		//this.name = string;
		this(string, i);//생성자 호출
		/*
		 * 같은 클래스에서 정의된 다른 생성자를 호출하는 키워드 this(type)
		 * 호출하려는 생성자의 파라미터 순서에 맞게 호출하면 자동 호출
		 * 단 this 생성자 호출은 생성자 첫머리에서만 호출 가능합니다.
		 * 딱 한 번만 호출 가능합니다.
		 */
		//this.age = i;
		this.money = j;
	}
	/*
	 * 생성자(메소드) 오버로드/오버로딩 238페이지에 나옵니다.
	 * 같은 이름의 메소드 또는 생성자를 정의할 때
	 * 같은지의 판별요소로 적용되는 기준을 메소드/생성자 시그니쳐라고 합니다.
	 * 이 시그니쳐는 파라미터의 갯수, 순서, 타입이 모두 같을 때
	 * 같은 생성자/메소드라고 인지합니다.
	 * 하나라도 다르다면 다른 메소드/생성자로 인식합니다.
	 * 
	 * 호출시 호출하는 파라미터의 시그니쳐를 보고
	 * 해당 생성자 또는 메소드를 동적으로 호출합니다.
	 * 이렇게 같은 이름의 생성자/메소드를 시그니쳐만 다르게 하여
	 * 정의하는 기술을 오버로딩이라고 합니다.
	 */

	void apple() {// 메소드
		System.out.println("생성자가 동작합니다.");
	}

	int sleep() {// 메소드
		return 0;
	}
}

public class Constructor01 {
	public static void main(String[] args) {
		Apple apple = new Apple("홍길동", 1);
		Apple apple2 = new Apple("김길동", 1);
		Apple apple3 = new Apple("김길동");
		Apple apple4 = new Apple("김길동", 1, 25000);

	}
}
