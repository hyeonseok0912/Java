package test;

import com.poseidon.constructor.Human;

public class Test01 {

	public static void main(String[] args) {
		Human h1 = new Human("홍길동", 150);
		System.out.println(h1.getName());
		
		h1.setMoney(5000);
		System.out.println(h1.getMoney());
		
		h1.setAddr("구로구 신림동");
		String addr = h1.getAddr();
		System.out.println(addr);
	}

}
